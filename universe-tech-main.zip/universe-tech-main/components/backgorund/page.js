
import styles from "./background.module.css";

export default function Background() {


  return (
      <>
     


      <div className={styles.area} >
        <ul className={styles.circles}>
                  <li></li>
                  <li></li>
                  <li></li>
                  <li></li>
                  <li></li>
                  <li></li>
                  <li></li>
                  <li></li>
                  <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>

          </ul>
      </div >
      </>
  ); 
};

